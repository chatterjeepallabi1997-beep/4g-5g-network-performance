-- MySQL examples. Import data/network_data_synthetic.csv as network_data.

SELECT
  Region,
  Technology,
  ROUND(AVG(Avg_Download_Mbps), 2) AS avg_download_mbps,
  ROUND(AVG(Drop_Rate_Pct), 2) AS avg_drop_rate_pct
FROM network_data
GROUP BY Region, Technology
ORDER BY Region, Technology;

SELECT
  Technology,
  ROUND(AVG(Avg_Download_Mbps), 2) AS avg_download_mbps,
  SUM(Handoffs) AS total_handoffs,
  SUM(Call_Drops) AS total_call_drops,
  ROUND(100.0 * SUM(Call_Drops) / NULLIF(SUM(Handoffs), 0), 2) AS weighted_drop_rate_pct
FROM network_data
GROUP BY Technology
ORDER BY avg_download_mbps DESC;

SELECT
  Month,
  Region,
  Technology,
  ROUND(AVG(Avg_Download_Mbps), 2) AS avg_download_mbps
FROM network_data
GROUP BY Month, Region, Technology
ORDER BY Month, Region, Technology;
