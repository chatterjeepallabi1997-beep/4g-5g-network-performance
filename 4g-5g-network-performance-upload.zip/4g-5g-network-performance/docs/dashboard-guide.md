# Dashboard guide

## KPI cards
- Average download speed (Mbps)
- Total handoffs
- Total call drops
- Weighted drop rate %

## Suggested visuals
- Average download speed by region and technology
- Drop rate by region and technology
- 4G vs 5G download-speed comparison
- Monthly download-speed trend

Compare technology and regions descriptively. Synthetic records are not evidence of actual operator performance or real-world 4G/5G improvement.
