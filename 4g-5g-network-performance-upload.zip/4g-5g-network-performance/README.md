# 4G vs 5G Network Performance

Compare synthetic network performance indicators across regions and 4G/5G technology.

## Data disclaimer
**The dataset in `data/network_data_synthetic.csv` is synthetic demo data.** It does not contain real subscriber records or production network measurements, and it does not establish verified business impact.

## Contents
- `data/network_data_synthetic.csv` — synthetic dataset for portfolio analysis.
- `sql/analysis.sql` — example MySQL queries.
- `powerbi/measures.dax` — starter Power BI measures.
- `docs/dashboard-guide.md` — suggested KPI cards, visuals, and interpretation notes.
- `docs/Pallabi_Dashboard_Portfolio_Synthetic_Demo.xlsx` — companion workbook containing all three synthetic demo dashboards.

## Suggested workflow
1. Import the CSV into Power BI or MySQL.
2. Validate column types, nulls, duplicates, and totals.
3. Build the measures and visuals in the dashboard guide.
4. Compare Power BI results against SQL aggregations.
5. Document assumptions and limitations before sharing.

## Important
These are portfolio starter materials, not a production model. Avoid describing synthetic dashboard results as real employer outcomes.
